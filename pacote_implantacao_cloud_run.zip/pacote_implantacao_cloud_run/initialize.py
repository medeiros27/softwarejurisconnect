#!/usr/bin/env python3
from src import app, db
from src.models.initialize import create_placeholder_images, initialize_database

if __name__ == '__main__':
    with app.app_context():
        # Criar imagens placeholder
        create_placeholder_images()
        
        # Inicializar banco de dados
        initialize_database()
        
        print("Inicialização concluída com sucesso!")
