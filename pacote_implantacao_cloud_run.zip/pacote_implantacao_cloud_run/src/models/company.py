from src import db
from datetime import datetime
import json

class Company(db.Model):
    __tablename__ = 'companies'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    document = db.Column(db.String(20), nullable=False)  # CNPJ/CPF
    company_name = db.Column(db.String(100), nullable=False)
    business_type = db.Column(db.String(50), nullable=False)  # law_firm, company, individual
    contact_name = db.Column(db.String(100))
    monthly_volume = db.Column(db.String(20))  # 1_to_5, 5_to_10, above_10
    locations = db.Column(db.Text)  # JSON array of {city, state}
    products_of_interest = db.Column(db.Text)  # JSON array of strings
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamentos
    service_requests = db.relationship('ServiceRequest', backref='company', lazy=True)
    
    def __repr__(self):
        return f'<Company {self.company_name}>'
    
    @property
    def locations_list(self):
        if self.locations:
            return json.loads(self.locations)
        return []
    
    @locations_list.setter
    def locations_list(self, value):
        self.locations = json.dumps(value)
    
    @property
    def products_of_interest_list(self):
        if self.products_of_interest:
            return json.loads(self.products_of_interest)
        return []
    
    @products_of_interest_list.setter
    def products_of_interest_list(self, value):
        self.products_of_interest = json.dumps(value)
