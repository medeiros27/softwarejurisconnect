from src import db
from datetime import datetime
import json

class Correspondent(db.Model):
    __tablename__ = 'correspondents'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    document = db.Column(db.String(20), nullable=False)  # CPF
    oab_number = db.Column(db.String(20))  # Número da OAB (opcional)
    specialties = db.Column(db.Text)  # JSON array de especialidades
    locations = db.Column(db.Text)  # JSON array de {city, state}
    rates = db.Column(db.Text)  # JSON object com taxas por tipo de serviço
    bank_info = db.Column(db.Text)  # JSON object com dados bancários
    average_rating = db.Column(db.Float, default=0.0)
    total_services = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamentos
    service_requests = db.relationship('ServiceRequest', backref='correspondent', lazy=True)
    
    def __repr__(self):
        return f'<Correspondent {self.id}>'
    
    @property
    def specialties_list(self):
        if self.specialties:
            return json.loads(self.specialties)
        return []
    
    @specialties_list.setter
    def specialties_list(self, value):
        self.specialties = json.dumps(value)
    
    @property
    def locations_list(self):
        if self.locations:
            return json.loads(self.locations)
        return []
    
    @locations_list.setter
    def locations_list(self, value):
        self.locations = json.dumps(value)
    
    @property
    def rates_dict(self):
        if self.rates:
            return json.loads(self.rates)
        return {}
    
    @rates_dict.setter
    def rates_dict(self, value):
        self.rates = json.dumps(value)
    
    @property
    def bank_info_dict(self):
        if self.bank_info:
            return json.loads(self.bank_info)
        return {}
    
    @bank_info_dict.setter
    def bank_info_dict(self, value):
        self.bank_info = json.dumps(value)
